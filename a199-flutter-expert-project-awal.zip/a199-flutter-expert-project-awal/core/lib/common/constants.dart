const String BASE_IMAGE_URL = 'https://image.tmdb.org/t/p/w500';
