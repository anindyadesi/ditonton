enum RequestState { Empty, Loading, Loaded, Error }
enum Opt { Movie, TvSeries }
